import os

CHECKPOINT_PATH = os.environ.get("FLARE_CHECKPOINT", "checkpoints/checkpoint_latest.pth")
TOKENIZER_PATH = os.environ.get("FLARE_TOKENIZER", "tokenizer/tokenizer.json")
CORS_ORIGINS = ["http://localhost:5173"]

STORAGE_ROOT = os.environ.get("FLARE_STORAGE_ROOT", "D:/flare-storage")
USER_MEMORY_QUOTA_BYTES = 4 * 1024 * 1024 * 1024  # 4GB
MAX_UPLOAD_FILE_BYTES = 50 * 1024 * 1024  # 50MB