import time

import firebase_admin
from firebase_admin import auth as firebase_auth
from firebase_admin import credentials, db

CREDENTIALS_PATH = "backend/firebase-credentials.json"
DATABASE_URL = "https://flare-corporation-default-rtdb.europe-west1.firebasedatabase.app/"

RESET_MS = 90 * 60 * 1000
MAX_LIMIT_USER = 100
MAX_LIMIT_ANON = 50
UNITS_PER_50_TOKENS = 0.2

_initialized = False


def init_firebase() -> None:
    global _initialized
    if _initialized:
        return
    cred = credentials.Certificate(CREDENTIALS_PATH)
    firebase_admin.initialize_app(cred, {"databaseURL": DATABASE_URL})
    _initialized = True


def verify_token(id_token: str) -> dict:
    decoded = firebase_auth.verify_id_token(id_token)
    return decoded


def get_limit_key(uid: str | None, anon_id: str | None) -> str:
    if uid:
        return f"limits/users/{uid}"
    return f"limits/anon/{anon_id}"


def check_and_get_usage(uid: str | None, anon_id: str | None) -> dict:
    key = get_limit_key(uid, anon_id)
    ref = db.reference(key)
    data = ref.get()
    now = int(time.time() * 1000)

    max_limit = MAX_LIMIT_USER if uid else MAX_LIMIT_ANON

    if not data or now > data.get("resetAt", 0):
        data = {"used": 0, "resetAt": now + RESET_MS}
        ref.set(data)

    return {"used": data["used"], "resetAt": data["resetAt"], "maxLimit": max_limit}


def add_usage(uid: str | None, anon_id: str | None, tokens_generated: int) -> dict:
    key = get_limit_key(uid, anon_id)
    ref = db.reference(key)
    cost = (tokens_generated / 50) * UNITS_PER_50_TOKENS
    now = int(time.time() * 1000)

    def transaction_update(current_data):
        if not current_data or now > current_data.get("resetAt", 0):
            return {"used": cost, "resetAt": now + RESET_MS}
        return {"used": current_data["used"] + cost, "resetAt": current_data["resetAt"]}

    ref.transaction(transaction_update)
    return ref.get()