import sys
from pathlib import Path

import torch
from tokenizers import Tokenizer

sys.path.append(str(Path(__file__).resolve().parent.parent))

from model.config import ModelConfig
from model.transformer import FlareSLM


class ModelService:
    def __init__(self, checkpoint_path: str, tokenizer_path: str):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.tokenizer = Tokenizer.from_file(tokenizer_path)
        self.config = ModelConfig()
        self.model = FlareSLM(self.config).to(self.device)

        checkpoint = torch.load(checkpoint_path, map_location=self.device)
        self.model.load_state_dict(checkpoint["model"])
        self.model.eval()

        self.eos_id = self.tokenizer.token_to_id("<eos>")
        self.think_id = self.tokenizer.token_to_id("<think>")
        self.bos_id = self.tokenizer.token_to_id("<bos>")

    def build_prompt(self, messages: list[dict]) -> list[int]:
        ids = [self.bos_id] if self.bos_id is not None else []
        for msg in messages:
            encoded = self.tokenizer.encode(f"{msg['role']}: {msg['content']}")
            ids.extend(encoded.ids)
            ids.append(self.eos_id)
        return ids

    @torch.no_grad()
    def generate(
        self,
        messages: list[dict],
        mode: str,
        max_new_tokens: int,
        temperature: float,
        top_k: int,
    ) -> tuple[str, int, int]:
        prompt_ids = self.build_prompt(messages)
        tokens_read = len(prompt_ids)

        input_ids = torch.tensor([prompt_ids], dtype=torch.long, device=self.device)
        deep_think = mode == "deepthink"
        generated = 0

        for step in range(max_new_tokens):
            context = input_ids[:, -self.config.max_seq_len :]
            logits, _, _ = self.model(context)
            next_logits = logits[:, -1, :] / temperature

            if not deep_think and step == 0:
                next_logits[:, self.think_id] = float("-inf")

            top_values, top_indices = torch.topk(next_logits, top_k)
            probs = torch.softmax(top_values, dim=-1)
            sampled = torch.multinomial(probs, num_samples=1)
            next_token = top_indices.gather(-1, sampled)

            input_ids = torch.cat([input_ids, next_token], dim=1)
            generated += 1

            if next_token.item() == self.eos_id:
                break

        output_ids = input_ids[0, len(prompt_ids):].tolist()
        text = self.tokenizer.decode(output_ids)
        return text, generated, tokens_read