from pydantic import BaseModel


class ChatMessage(BaseModel):
    role: str
    content: str


class ChatRequest(BaseModel):
    messages: list[ChatMessage]
    mode: str = "fast"
    max_new_tokens: int = 512
    temperature: float = 0.8
    top_k: int = 40


class ChatResponse(BaseModel):
    content: str
    tokens_generated: int
    tokens_read: int