from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware

from backend.config import CHECKPOINT_PATH, TOKENIZER_PATH, CORS_ORIGINS
from backend.model_service import ModelService
from backend.schemas import ChatRequest, ChatResponse
from backend.firebase_service import (
    init_firebase,
    verify_token,
    check_and_get_usage,
    add_usage,
)

model_service: ModelService | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global model_service
    init_firebase()
    model_service = ModelService(CHECKPOINT_PATH, TOKENIZER_PATH)
    yield


app = FastAPI(title="Flare API", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_methods=["*"],
    allow_headers=["*"],
)


def resolve_identity(authorization: str | None, x_anon_id: str | None) -> tuple[str | None, str | None]:
    if authorization and authorization.startswith("Bearer "):
        token = authorization.split(" ", 1)[1]
        try:
            decoded = verify_token(token)
            return decoded["uid"], None
        except Exception:
            raise HTTPException(status_code=401, detail="Invalid auth token")

    if not x_anon_id:
        raise HTTPException(status_code=400, detail="Missing anonymous identifier")

    return None, x_anon_id


@app.post("/api/chat", response_model=ChatResponse)
async def chat(
    request: ChatRequest,
    authorization: str | None = Header(default=None),
    x_anon_id: str | None = Header(default=None),
):
    if model_service is None:
        raise HTTPException(status_code=503, detail="Model not loaded")

    uid, anon_id = resolve_identity(authorization, x_anon_id)

    usage = check_and_get_usage(uid, anon_id)
    if usage["used"] >= usage["maxLimit"]:
        raise HTTPException(status_code=429, detail="Limit reached")

    messages = [m.model_dump() for m in request.messages]

    text, tokens_generated, tokens_read = model_service.generate(
        messages,
        request.mode,
        request.max_new_tokens,
        request.temperature,
        request.top_k,
    )

    add_usage(uid, anon_id, tokens_generated)

    return ChatResponse(
        content=text,
        tokens_generated=tokens_generated,
        tokens_read=tokens_read,
    )
@app.post("/api/title")
async def generate_title(
    request: dict,
    authorization: str | None = Header(default=None),
    x_anon_id: str | None = Header(default=None),
):
    if model_service is None:
        raise HTTPException(status_code=503, detail="Model not loaded")

    resolve_identity(authorization, x_anon_id)

    message = request.get("message", "")
    prompt = [{"role": "user", "content": f"Bu mesaj üçün 3-5 sözlük qısa başlıq yaz: {message}"}]

    title, _, _ = model_service.generate(prompt, "fast", max_new_tokens=20, temperature=0.5, top_k=20)
    return {"title": title.strip()[:40]}

@app.get("/api/health")
async def health():
    return {"status": "ok", "model_loaded": model_service is not None}