import shutil
from pathlib import Path

from backend.config import STORAGE_ROOT, USER_MEMORY_QUOTA_BYTES, MAX_UPLOAD_FILE_BYTES


class QuotaExceededError(Exception):
    pass


class FileTooLargeError(Exception):
    pass


def get_user_dir(user_id: str) -> Path:
    user_dir = Path(STORAGE_ROOT) / user_id
    user_dir.mkdir(parents=True, exist_ok=True)
    return user_dir


def get_user_usage_bytes(user_id: str) -> int:
    user_dir = get_user_dir(user_id)
    return sum(f.stat().st_size for f in user_dir.rglob("*") if f.is_file())


def save_user_file(user_id: str, filename: str, file_bytes: bytes) -> Path:
    if len(file_bytes) > MAX_UPLOAD_FILE_BYTES:
        raise FileTooLargeError(f"File exceeds {MAX_UPLOAD_FILE_BYTES // (1024 * 1024)}MB limit")

    current_usage = get_user_usage_bytes(user_id)
    if current_usage + len(file_bytes) > USER_MEMORY_QUOTA_BYTES:
        raise QuotaExceededError("User storage quota exceeded")

    user_dir = get_user_dir(user_id)
    file_path = user_dir / filename
    file_path.write_bytes(file_bytes)
    return file_path


def save_user_text(user_id: str, filename: str, text: str) -> Path:
    return save_user_file(user_id, filename, text.encode("utf-8"))


def read_user_file(user_id: str, filename: str) -> bytes:
    file_path = get_user_dir(user_id) / filename
    if not file_path.exists():
        raise FileNotFoundError(filename)
    return file_path.read_bytes()


def list_user_files(user_id: str) -> list[str]:
    user_dir = get_user_dir(user_id)
    return [f.name for f in user_dir.iterdir() if f.is_file()]


def delete_user_file(user_id: str, filename: str) -> None:
    file_path = get_user_dir(user_id) / filename
    if file_path.exists():
        file_path.unlink()


def delete_all_user_data(user_id: str) -> None:
    user_dir = get_user_dir(user_id)
    if user_dir.exists():
        shutil.rmtree(user_dir)