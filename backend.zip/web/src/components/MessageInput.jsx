import { useState } from "react";
import ModeDropdown from "./ModeDropdown";

export default function MessageInput({ onSend, mode, setMode, t, disabled }) {
  const [text, setText] = useState("");

  function handleSend() {
    const trimmed = text.trim();
    if (!trimmed || disabled) return;
    onSend(trimmed);
    setText("");
  }

  function handleKeyDown(e) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }

  return (
    <div className="input-area">
      <div className="input-container">
        <ModeDropdown mode={mode} setMode={setMode} t={t} />
        <textarea
          className="message-input"
          rows={1}
          placeholder={t.sendPlaceholder}
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={handleKeyDown}
        />
        <button className="send-btn" onClick={handleSend} disabled={disabled || !text.trim()}>
          ↑
        </button>
      </div>
    </div>
  );
}