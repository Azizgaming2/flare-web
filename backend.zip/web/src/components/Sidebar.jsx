export default function Sidebar({
  chats,
  activeChatId,
  onSelectChat,
  onNewChat,
  t,
  user,
  onOpenSettings,
  onLogIn,
}) {
  return (
    <div className="sidebar">
      <div className="sidebar-header">
        <button className="new-chat-btn" onClick={onNewChat}>
          + {t.newChat}
        </button>
      </div>

      <div className="chat-history">
        {chats.map((chat) => (
          <div
            key={chat.id}
            className={`chat-history-item ${chat.id === activeChatId ? "active" : ""}`}
            onClick={() => onSelectChat(chat.id)}
          >
            {chat.title}
          </div>
        ))}
      </div>

      <div className="sidebar-footer">
        {user ? (
          <div className="user-info" onClick={onOpenSettings}>
            <div className="avatar">
              {user.avatarUrl ? <img src={user.avatarUrl} alt="" referrerPolicy="no-referrer" /> : (user.nickname?.[0] || user.name?.[0] || "U")}
            </div>
            <span>{user.nickname || user.name}</span>
          </div>
        ) : (
          <button className="new-chat-btn" onClick={onLogIn}>
            {t.logIn}
          </button>
        )}
      </div>
    </div>
  );
}