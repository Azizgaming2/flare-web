import { useEffect, useState } from "react";
import { getRandomPhrase } from "../data/loadingPhrases";

export default function LoadingIndicator({ lang }) {
  const [phrase, setPhrase] = useState(() => getRandomPhrase(lang));

  useEffect(() => {
    const interval = setInterval(() => {
      setPhrase(getRandomPhrase(lang));
    }, 2500);
    return () => clearInterval(interval);
  }, [lang]);

  return <div className="message-bubble assistant loading">{phrase}...</div>;
}