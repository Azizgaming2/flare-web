import { useState } from "react";

export default function MessageBubble({ role, content, avatarUrl }) {
  const isUser = role === "user";
  const [copied, setCopied] = useState(false);

  function handleCopy() {
    navigator.clipboard.writeText(content).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    });
  }

  if (isUser) {
    return (
      <div className="message-row user">
        <div className="avatar">
          {avatarUrl ? <img src={avatarUrl} alt="" referrerPolicy="no-referrer" /> : "U"}
        </div>
        <div className="message-bubble user">{content}</div>
      </div>
    );
  }

  return (
    <div className="message-row assistant">
      <div className="assistant-content">
        <div className="message-bubble assistant">{content}</div>
        <button className="copy-btn" onClick={handleCopy} title="Kopyala">
          {copied ? "✓" : "⧉"}
        </button>
      </div>
    </div>
  );
}