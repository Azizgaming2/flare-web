import { useEffect, useRef } from "react";
import MessageBubble from "./MessageBubble";
import LoadingIndicator from "./LoadingIndicator";

export default function ChatWindow({ messages, isLoading, lang, emptyText, userAvatarUrl }) {
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  if (messages.length === 0 && !isLoading) {
    return (
      <div className="empty-state-wrapper">
        <div className="gradient-orb" />
        <div className="empty-state">{emptyText}</div>
      </div>
    );
  }

  return (
    <div className="chat-window">
      {messages.map((msg, idx) => (
        <MessageBubble
          key={idx}
          role={msg.role}
          content={msg.content}
          avatarUrl={msg.role === "user" ? userAvatarUrl : null}
        />
      ))}
      {isLoading && (
        <div className="message-row assistant">
          <LoadingIndicator lang={lang} />
        </div>
      )}
      <div ref={bottomRef} />
    </div>
  );
}