import { useState } from "react";
import { languageOptions } from "../locales/translations";

export default function SettingsModal({ user, setUser, lang, setLang, t, onClose, onLogOut, onDeleteAllChats }) {
  const [activeTab, setActiveTab] = useState("general");
  const [nickname, setNickname] = useState(user?.nickname || "");
  const [confirmingDelete, setConfirmingDelete] = useState(false);

  function saveNickname() {
    setUser({ ...user, nickname });
  }

  function handleAvatarUpload(e) {
    const file = e.target.files[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    setUser({ ...user, avatarUrl: url });
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="settings-modal" onClick={(e) => e.stopPropagation()}>
        <div className="settings-sidebar">
          <div className="settings-title">{t.settings}</div>
          <div
            className={`settings-tab ${activeTab === "general" ? "active" : ""}`}
            onClick={() => setActiveTab("general")}
          >
            {t.general}
          </div>
          <div
            className={`settings-tab ${activeTab === "account" ? "active" : ""}`}
            onClick={() => setActiveTab("account")}
          >
            {t.account}
          </div>
          <div
            className={`settings-tab ${activeTab === "data" ? "active" : ""}`}
            onClick={() => setActiveTab("data")}
          >
            {t.dataControls}
          </div>
        </div>

        <div className="settings-panel">
          <button className="modal-close" onClick={onClose}>✕</button>

          {activeTab === "general" && (
            <>
              <div className="settings-row">
                <div>
                  <div className="settings-label-main">{t.language}</div>
                </div>
                <select className="settings-select" value={lang} onChange={(e) => setLang(e.target.value)}>
                  {languageOptions.map((opt) => (
                    <option key={opt.code} value={opt.code}>{opt.label}</option>
                  ))}
                </select>
              </div>
              <div className="settings-row">
                <div>
                  <div className="settings-label-main">{t.appVersion}</div>
                </div>
                <span className="settings-value-muted">v0.1.0</span>
              </div>
            </>
          )}

          {activeTab === "account" && (
            <>
              <div className="settings-row">
                <div>
                  <div className="settings-label-main">{t.avatar}</div>
                  <div className="settings-label-desc">{t.avatarDesc}</div>
                </div>
                <div className="avatar-upload-group">
                  <div className="avatar avatar-lg">
                    {user?.avatarUrl ? <img src={user.avatarUrl} alt="" /> : (user?.nickname?.[0] || "U")}
                  </div>
                  <label className="btn-secondary avatar-upload-btn">
                    {t.changeAvatar}
                    <input type="file" accept="image/*" hidden onChange={handleAvatarUpload} />
                  </label>
                </div>
              </div>
              <div className="settings-row">
                <div>
                  <div className="settings-label-main">{t.nickname}</div>
                  <div className="settings-label-desc">{t.nicknameDesc}</div>
                </div>
                <input
                  className="settings-input"
                  value={nickname}
                  onChange={(e) => setNickname(e.target.value)}
                  onBlur={saveNickname}
                />
              </div>
              <div className="settings-row">
                <button className="btn-secondary" onClick={onLogOut}>{t.logOut}</button>
              </div>
            </>
          )}

          {activeTab === "data" && (
            <div className="settings-row">
              <div>
                <div className="settings-label-main">{t.deleteAllChats}</div>
                <div className="settings-label-desc">{t.deleteAllChatsDesc}</div>
              </div>
              {confirmingDelete ? (
                <div className="confirm-actions">
                  <button className="btn-secondary" onClick={() => setConfirmingDelete(false)}>{t.cancel}</button>
                  <button
                    className="btn-danger"
                    onClick={() => {
                      onDeleteAllChats();
                      setConfirmingDelete(false);
                    }}
                  >
                    {t.confirm}
                  </button>
                </div>
              ) : (
                <button className="danger-btn" onClick={() => setConfirmingDelete(true)}>{t.deleteAllChats}</button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}