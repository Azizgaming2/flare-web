import { auth } from "../firebase";
import { getAnonId } from "../hooks/UseLimit";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:8000";

export async function sendChatMessage(messages, mode) {
  const headers = { "Content-Type": "application/json" };

  if (auth.currentUser) {
    const token = await auth.currentUser.getIdToken();
    headers["Authorization"] = `Bearer ${token}`;
  } else {
    headers["X-Anon-Id"] = getAnonId();
  }

  const response = await fetch(`${API_BASE_URL}/api/chat`, {
    method: "POST",
    headers,
    body: JSON.stringify({ messages, mode }),
  });

  if (response.status === 429) {
    throw new Error("LIMIT_REACHED");
  }

  if (!response.ok) {
    throw new Error(`API error: ${response.status}`);
  }

  return response.json();
}
export async function generateChatTitle(firstMessage) {
  try {
    const headers = { "Content-Type": "application/json" };
    if (auth.currentUser) {
      const token = await auth.currentUser.getIdToken();
      headers["Authorization"] = `Bearer ${token}`;
    } else {
      headers["X-Anon-Id"] = getAnonId();
    }

    const response = await fetch(`${API_BASE_URL}/api/title`, {
      method: "POST",
      headers,
      body: JSON.stringify({ message: firstMessage }),
    });

    if (!response.ok) return firstMessage.slice(0, 30);
    const data = await response.json();
    return data.title;
  } catch {
    return firstMessage.slice(0, 30);
  }
}