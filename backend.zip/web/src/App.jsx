import { useState, useEffect, useMemo } from "react";
import SplashScreen from "./components/SplashScreen";
import Sidebar from "./components/Sidebar";
import ChatWindow from "./components/ChatWindow";
import MessageInput from "./components/MessageInput";
import SettingsModal from "./components/SettingsModal";
import LimitBar from "./components/LimitBar";
import { translations } from "./locales/translations";
import { useAuth } from "./hooks/UseAuth";
import { useLimit } from "./hooks/UseLimit";
import { loginWithGoogle, logout } from "./firebase";

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [lang, setLang] = useState("az");
  const [mode, setMode] = useState("fast");
  const [showSettings, setShowSettings] = useState(false);
  const [chats, setChats] = useState([]);
  const [activeChatId, setActiveChatId] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const { user, setUser } = useAuth();
  const { percentUsed, isLimitReached, addUsage } = useLimit(user);

  const t = translations[lang];

  useEffect(() => {
    const timer = setTimeout(() => setShowSplash(false), 1200);
    return () => clearTimeout(timer);
  }, []);

  const activeChat = chats.find((c) => c.id === activeChatId);
  const messages = activeChat?.messages || [];

  const greeting = useMemo(
    () =>
      t.greetings[Math.floor(Math.random() * t.greetings.length)].replace(
        "{name}",
        user?.nickname || user?.name || "!"
      ),
    [t, user, activeChatId]
  );

  function handleNewChat() {
    const newChat = { id: Date.now().toString(), title: t.newChat, messages: [] };
    setChats([newChat, ...chats]);
    setActiveChatId(newChat.id);
  }

  async function handleSend(text) {
    if (isLimitReached) return;

    let chatId = activeChatId;
    let updatedChats = chats;

    if (!chatId) {
      const newChat = { id: Date.now().toString(), title: text.slice(0, 30), messages: [] };
      updatedChats = [newChat, ...chats];
      chatId = newChat.id;
      setActiveChatId(chatId);
    }

    updatedChats = updatedChats.map((c) =>
      c.id === chatId ? { ...c, messages: [...c.messages, { role: "user", content: text }] } : c
    );
    setChats(updatedChats);
    setIsLoading(true);

    // Placeholder: backend inteqrasiyası olana qədər simulyasiya
    setTimeout(async () => {
      const fakeResponse = "...";
      const tokensGenerated = fakeResponse.split(" ").length;

      setChats((prev) =>
        prev.map((c) =>
          c.id === chatId
            ? { ...c, messages: [...c.messages, { role: "assistant", content: fakeResponse }] }
            : c
        )
      );
      setIsLoading(false);
      await addUsage(tokensGenerated);
    }, 1500);
  }

  function handleDeleteAllChats() {
    setChats([]);
    setActiveChatId(null);
  }

  async function handleLogIn() {
    try {
      await loginWithGoogle();
    } catch (err) {
      console.error("Login failed:", err);
    }
  }

  async function handleLogOut() {
    await logout();
    setShowSettings(false);
  }

  if (showSplash) return <SplashScreen />;

  return (
    <div className="app-layout">
      <Sidebar
        chats={chats}
        activeChatId={activeChatId}
        onSelectChat={setActiveChatId}
        onNewChat={handleNewChat}
        t={t}
        user={user}
        onOpenSettings={() => setShowSettings(true)}
        onLogIn={handleLogIn}
      />

      <div className="chat-main">
        <ChatWindow
          messages={messages}
          isLoading={isLoading}
          lang={lang}
          emptyText={greeting}
          userAvatarUrl={user?.avatarUrl}
        />
        <LimitBar
          percentUsed={percentUsed}
          isLimitReached={isLimitReached}
          isLoggedIn={!!user}
          t={t}
        />
        <MessageInput
          onSend={handleSend}
          mode={mode}
          setMode={setMode}
          t={t}
          disabled={isLoading || isLimitReached}
        />
      </div>

      {showSettings && (
        <SettingsModal
          user={user}
          setUser={setUser}
          lang={lang}
          setLang={setLang}
          t={t}
          onClose={() => setShowSettings(false)}
          onLogOut={handleLogOut}
          onDeleteAllChats={handleDeleteAllChats}
        />
      )}
    </div>
  );
}